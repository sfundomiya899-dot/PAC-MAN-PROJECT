import pygame
import sys
import random
from enum import Enum


# ---------- Constants ----------
TILE = 24
ROWS, COLS = 21, 19
WIDTH, HEIGHT = COLS * TILE, ROWS * TILE + 40
FPS = 60

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
YELLOW = (255, 235, 59)
BLUE = (25, 25, 112)
RED = (255, 82, 82)
PINK = (255, 143, 171)
CYAN = (0, 229, 255)
ORANGE = (255, 160, 0)
FRIGHT = (33, 33, 222)


# Maze legend:
# '#' wall
# '.' dot
# 'o' power pellet
# ' ' empty
# '-' ghost door

MAZE = [
    "###################",
    "#........#........#",
    "#o##.###.#.###.##o#",
    "#.................#",
    "#.##.#.#####.#.##.#",
    "#....#...#...#....#",
    "####.###.#.###.####",
    "####.#.......#.####",
    "####.#.##-##.#.####",
    "#......#---#......#",
    "####.#.#####.#.####",
    "####.#.......#.####",
    "####.#.#####.#.####",
    "#........#........#",
    "#.##.###.#.###.##.#",
    "#o..#..........#..#",
    "###.#.#.#####.#.###",
    "###.#.#.....#.#.###",
    "#.....#.###.#.....#",
    "###################",
]


class Dir(Enum):
    UP = (0, -1)
    DOWN = (0, 1)
    LEFT = (-1, 0)
    RIGHT = (1, 0)


# ---------- Pygame setup ----------
pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("PAC-MAN")

clock = pygame.time.Clock()

font = pygame.font.Font(None, 28)
big_font = pygame.font.Font(None, 64)


# ---------- Board ----------
class Board:
    def __init__(self, layout):
        self.grid = [list(row) for row in layout]
        self.dots = 0

        for y, row in enumerate(self.grid):
            for x, ch in enumerate(row):
                if ch in (".", "o"):
                    self.dots += 1

    def is_wall(self, x, y):
        if 0 <= x < COLS and 0 <= y < ROWS:
            return self.grid[y][x] == "#"

        return True

    def at(self, x, y):
        if 0 <= x < COLS and 0 <= y < ROWS:
            return self.grid[y][x]

        return "#"

    def eat(self, x, y):
        """Eat a dot/pellet at tile. Returns 'dot', 'power', or None."""

        if not (0 <= x < COLS and 0 <= y < ROWS):
            return None

        if self.grid[y][x] == ".":
            self.grid[y][x] = " "
            self.dots -= 1
            return "dot"

        if self.grid[y][x] == "o":
            self.grid[y][x] = " "
            self.dots -= 1
            return "power"

        return None


# ---------- Actors ----------
class Actor:
    def __init__(self, x, y, color, speed):
        self.tile_x = x
        self.tile_y = y

        self.px = x * TILE
        self.py = y * TILE

        self.color = color
        self.speed = speed

        self.dir = None
        self.next_dir = None
        self.mouth = 0

    def tile_centered(self):
        return self.px % TILE == 0 and self.py % TILE == 0

    def can_move(self, direction, board):
        if direction is None:
            return False

        nx = self.tile_x + direction.value[0]
        ny = self.tile_y + direction.value[1]

        return not board.is_wall(nx, ny)

    def update_tile(self):
        self.tile_x = round(self.px / TILE)
        self.tile_y = round(self.py / TILE)

    def draw(self, surf):
        cx = self.px + TILE // 2
        cy = self.py + TILE // 2 + 40

        pygame.draw.circle(
            surf,
            self.color,
            (cx, cy),
            TILE // 2 - 2
        )


# ---------- Pac-Man ----------
class Pacman(Actor):
    def __init__(self, x, y):
        super().__init__(x, y, YELLOW, 3)

    def move(self, board):
        if self.tile_centered():
            self.update_tile()

            # Try requested direction first
            if self.next_dir and self.can_move(self.next_dir, board):
                self.dir = self.next_dir

            # Stop if current direction is blocked
            if not self.can_move(self.dir, board):
                self.dir = None

        if self.dir:
            self.px += self.dir.value[0] * self.speed
            self.py += self.dir.value[1] * self.speed

            self.mouth = (self.mouth + 1) % 30

    def draw(self, surf):
        cx = self.px + TILE // 2
        cy = self.py + TILE // 2 + 40

        # Direction Pac-Man is facing
        if self.dir == Dir.LEFT:
            base = 180
        elif self.dir == Dir.UP:
            base = 90
        elif self.dir == Dir.DOWN:
            base = 270
        else:
            base = 0

        mouth_angle = 30 + 15 * abs(15 - self.mouth) // 15

        v1 = pygame.math.Vector2(1, 0).rotate(
            base - mouth_angle
        )

        v2 = pygame.math.Vector2(1, 0).rotate(
            base + mouth_angle
        )

        pygame.draw.circle(
            surf,
            YELLOW,
            (cx, cy),
            TILE // 2 - 2
        )

        pygame.draw.polygon(
            surf,
            BLACK,
            [
                (cx, cy),
                (
                    cx + (TILE // 2) * v1.x,
                    cy + (TILE // 2) * v1.y
                ),
                (
                    cx + (TILE // 2) * v2.x,
                    cy + (TILE // 2) * v2.y
                ),
            ]
        )


# ---------- Ghost ----------
class Ghost(Actor):
    COLORS = [RED, PINK, CYAN, ORANGE]

    def __init__(self, x, y, idx):
        super().__init__(
            x,
            y,
            self.COLORS[idx],
            2
        )

        self.home = (x, y)
        self.frightened = 0
        self.in_house = idx != 0

    def choose_dir(self, board, pac):
        options = [
            direction
            for direction in Dir
            if self.can_move(direction, board)
        ]

        # Prevent reversing unless there are no other options
        if self.dir and len(options) > 1:
            reverse = Dir(
                (
                    -self.dir.value[0],
                    -self.dir.value[1]
                )
            )

            options = [
                direction
                for direction in options
                if direction != reverse
            ]

        if not options:
            return None

        # Frightened ghosts move randomly
        if self.frightened > 0:
            return random.choice(options)

        # Otherwise chase Pac-Man
        best = None
        best_distance = float("inf")

        for direction in options:
            nx = self.tile_x + direction.value[0]
            ny = self.tile_y + direction.value[1]

            distance = (
                (nx - pac.tile_x) ** 2
                + (ny - pac.tile_y) ** 2
            )

            if distance < best_distance:
                best = direction
                best_distance = distance

        return best

    def move(self, board, pac):
        if self.frightened > 0:
            self.frightened -= 1

        if self.tile_centered():
            self.update_tile()
            self.dir = self.choose_dir(board, pac)

        if self.dir:
            self.px += self.dir.value[0] * self.speed
            self.py += self.dir.value[1] * self.speed

    def respawn(self):
        self.px = self.home[0] * TILE
        self.py = self.home[1] * TILE

        self.tile_x, self.tile_y = self.home

        self.frightened = 0
        self.dir = None

    def draw(self, surf):
        cx = self.px + TILE // 2
        cy = self.py + TILE // 2 + 40

        color = (
            FRIGHT
            if self.frightened > 0
            else self.color
        )

        # Ghost head
        pygame.draw.circle(
            surf,
            color,
            (cx, cy - 2),
            TILE // 2 - 2
        )

        # Ghost body
        pygame.draw.rect(
            surf,
            color,
            (
                cx - TILE // 2 + 2,
                cy - 2,
                TILE - 4,
                TILE // 2
            )
        )


# ---------- Game ----------
def main():
    board = Board(MAZE)

    pac = Pacman(9, 15)

    ghosts = [
        Ghost(8, 9, 0),
        Ghost(9, 9, 1),
        Ghost(10, 9, 2),
        Ghost(9, 8, 3),
    ]

    score = 0
    lives = 3
    state = "play"

    KEYMAP = {
        pygame.K_UP: Dir.UP,
        pygame.K_DOWN: Dir.DOWN,
        pygame.K_LEFT: Dir.LEFT,
        pygame.K_RIGHT: Dir.RIGHT,

        pygame.K_w: Dir.UP,
        pygame.K_s: Dir.DOWN,
        pygame.K_a: Dir.LEFT,
        pygame.K_d: Dir.RIGHT,
    }

    while True:
        clock.tick(FPS)

        # ---------- Events ----------
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:

                if event.key in KEYMAP and state == "play":
                    pac.next_dir = KEYMAP[event.key]

                if event.key == pygame.K_r:
                    if state != "play":
                        return main()

        # ---------- Update ----------
        if state == "play":

            pac.move(board)

            for ghost in ghosts:
                ghost.move(board, pac)

            # Eat dots / power pellets
            item = board.eat(
                pac.tile_x,
                pac.tile_y
            )

            if item == "dot":
                score += 10

            elif item == "power":
                score += 50

                for ghost in ghosts:
                    ghost.frightened = 400

            # ---------- Ghost collisions ----------
            for ghost in ghosts:

                if (
                    ghost.tile_x == pac.tile_x
                    and ghost.tile_y == pac.tile_y
                ):

                    if ghost.frightened > 0:
                        score += 200
                        ghost.respawn()

                    else:
                        lives -= 1

                        pac = Pacman(9, 15)

                        for other_ghost in ghosts:
                            other_ghost.respawn()

                        if lives <= 0:
                            state = "gameover"

            # ---------- Win condition ----------
            if board.dots == 0:
                state = "win"

        # ---------- Drawing ----------
        screen.fill(BLACK)

        # Draw maze
        for y, row in enumerate(board.grid):

            for x, ch in enumerate(row):

                rect = pygame.Rect(
                    x * TILE,
                    y * TILE + 40,
                    TILE,
                    TILE
                )

                if ch == "#":
                    pygame.draw.rect(
                        screen,
                        BLUE,
                        rect
                    )

                elif ch == ".":
                    pygame.draw.circle(
                        screen,
                        WHITE,
                        rect.center,
                        3
                    )

                elif ch == "o":
                    pygame.draw.circle(
                        screen,
                        WHITE,
                        rect.center,
                        7
                    )

        # ---------- HUD ----------
        score_text = font.render(
            f"SCORE {score}",
            True,
            WHITE
        )

        lives_text = font.render(
            f"LIVES {'o' * lives}",
            True,
            YELLOW
        )

        screen.blit(
            score_text,
            (10, 8)
        )

        screen.blit(
            lives_text,
            (WIDTH - 130, 8)
        )

        # ---------- Actors ----------
        pac.draw(screen)

        for ghost in ghosts:
            ghost.draw(screen)

        # ---------- End screen ----------
        if state in ("win", "gameover"):

            if state == "win":
                message = "YOU WIN!  Press R"
                color = YELLOW
            else:
                message = "GAME OVER  Press R"
                color = RED

            text_surface = big_font.render(
                message,
                True,
                color
            )

            screen.blit(
                text_surface,
                (
                    WIDTH // 2
                    - text_surface.get_width() // 2,
                    HEIGHT // 2 - 20
                )
            )

        pygame.display.flip()


# ---------- Start ----------
if __name__ == "__main__":
    main()